/* eslint-disable jsx-a11y/alt-text */
import React from 'react'
import nav from '../assets/nav.png';
import eventButton from '../assets/eventButton.png'
import middle from '../assets/middle.png'
import left from '../assets/left.png'
import right from '../assets/right.png'
import "../App.css";
function Landing() {
    return (
        <div className="Container">
            <div className="Navigation">
                <img src={nav} width="100%"
                    height="100%" />
            </div>
            <div className="center-flex">
                <div>
                    <h1>Facebook events <br />
                        without Facebook.
                    </h1>

                </div>
                <div>
                    <h6>Easily host and share events with your <br />
                        <span>friends accross my social media</span>
                    </h6>
                </div>
                <div className="event-btn">
                    <img src={eventButton} width="100%" height="100%"></img>
                </div>
                <div className="social-media">
                    <div>
                        <img src={left} width="100%" height="100%"></img>
                    </div>
                    <div>
                        <img src={middle} width="100%" height="100%"></img>
                    </div>
                    <div>
                        <img src={right} width="100%" height="100%"></img>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Landing
