/* eslint-disable jsx-a11y/alt-text */
import React from 'react'
import './styleEvent.css';
import bg from '../assets/bg.png';
import birthday from '../assets/birthday.png'
import tick from '../assets/tick.png'
import questionMark from '../assets/questionMark.png';
import cross from '../assets/cross.png';
import invite from '../assets/invite.png';
import dots from '../assets/dots.png';
import info from '../assets/info.png';
import details from '../assets/details.png';
import post from '../assets/post.png';
function Event() {
    return (
        <div className="eventContainer">
            <div className="eventNavBar">
                <img src={bg} width="100%" height="100%" />
            </div>
            <div className="happyBirthday">
                <img src={birthday} width="100%" height="100%"></img>
            </div>
            <div className="Birthdayname">
                <h5>Anica's 22nd <br />
                    Birthday
                </h5>
                <span> Hosted by Anica</span>
            </div>
            <div className="icons">
                <div>
                    <img src={tick} height="100%" width="100%"></img>
                </div>
                <div>
                    <img src={questionMark} height="100%" width="100%"></img>
                </div>
                <div>
                    <img src={cross} height="100%" width="100%"></img>
                </div>
            </div>
            <div className="invite">
                <div>
                    <img src={invite} height="100%" width="100%"></img>
                </div>
                <div>
                    <img src={dots} height="100%" width="100%"></img>
                </div>
            </div>
            <div className="info">
                <img src={info} height="100%" width="100%"></img>
            </div>
            <div className="details">
                <div>
                    <img src={details} height="100%" width="100%"></img>
                </div>
                <div>
                    <img src={post} height="100%" width="100%"></img>
                </div>

            </div>
            <div>
                <div>
                    <h3>Just a locky dinner to  celebrate </h3>
                </div>
            </div>
        </div>
    )
}

export default Event
