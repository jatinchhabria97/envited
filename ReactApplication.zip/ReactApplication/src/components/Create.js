import React from 'react';
import './Create.css';

function Create() {
    return (
        <div class="container">
            <form>
                <label className='label'>
                    Event Name:
                    <input type="text" name="event" id='inp' />
                </label><br></br>
                <label className='label'>
                    Host Name:
                    <input type="text" name="host" id='inp' />
                </label><br></br>
                <label className='label'>
                    Start Time & Date:
                    <input type="datetime-local" name="start" id='inp' />
                </label><br></br>
                <label className='label'>
                    End Time & Date:
                    <input type="datetime-local" name="end" id='inp' />
                </label><br></br>
                <br></br>
                <hr></hr>
                <input type="submit" value="Next" className='nxt' />
                <br></br>
                {/* <Link to={{
                    pathname: '/Event',
                    state: [{id: 1, name: 'Ford', color: 'red'}]
                    }}> Your Page </Link> */}
            </form>
        </div>
    )
}

export default Create