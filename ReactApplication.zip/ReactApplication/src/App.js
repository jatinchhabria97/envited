import logo from './logo.svg';
import './App.css';
import { Routes, Route } from 'react-router-dom';
import Landing from './components/Landing';
import Event from './components/EventPage';
import Create from './components/Create';

function App() {
  return (
    <main>
      <Routes>
        <Route path="/" element={<Landing />} exact />
        <Route path="/Create" element={<Create />} exact />
        <Route path="/Event" element={<Event />} exact />
      </Routes>
    </main>
  );
}

export default App;
